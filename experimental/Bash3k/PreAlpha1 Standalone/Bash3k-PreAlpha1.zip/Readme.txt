Welcome to Bash3k Pre-Alpha 1. Please forgive the mess, it is very much a work in progress.

To get started:
1) Extract Bash3k-PreAlpha1.zip to any directory. Bash no longer needs to be installed within the game directory.
2) Open Profiles\0\profile.ini and edit p_Directory to point to your Skyrim directory.
3) Save and close profile.ini
4) Launch Bash3k Pre-Alpha 1 by running: Wrye Bash Launcher.exe

Tabs can be rearranged by dragging the tab with the right mouse button
Mods can be activated/deactivated by double-clicking the mod
Mods can be rearranged by selecting the mod(s) and pressing Control-Up or Control-Down
